// api/fpl.js
// Vercel Serverless Function — proxies FPL API requests
// This runs in the cloud so your iPad never needs a local server

const https = require('https');

module.exports = async (req, res) => {
  // Allow requests from any origin (your browser/iPad)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // Handle preflight
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // Build the FPL API path from the query string
  // e.g. /api/fpl?path=bootstrap-static
  // e.g. /api/fpl?path=entry/1234567
  const path = req.query.path;

  if (!path) {
    res.status(400).json({ error: 'Missing ?path= parameter' });
    return;
  }

  const fplUrl = `https://fantasy.premierleague.com/api/${path}/`;

  try {
    const data = await fetchJSON(fplUrl);
    res.setHeader('Cache-Control', 's-maxage=30, stale-while-revalidate=60');
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Simple HTTPS fetch (no external dependencies needed)
function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; FPLLive/1.0)',
        'Accept': 'application/json',
      },
    };
    https.get(url, options, (response) => {
      let data = '';
      response.on('data', chunk => data += chunk);
      response.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('Invalid JSON from FPL API')); }
      });
    }).on('error', reject);
  });
}
